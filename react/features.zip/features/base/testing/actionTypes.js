/**
 * The type of redux action which sets the configuration of the feature
 * base/logging.
 *
 * {
 *     type: SET_CONNECTION_STATE
 * }
 */
export const SET_CONNECTION_STATE = 'SET_CONNECTION_STATE';
