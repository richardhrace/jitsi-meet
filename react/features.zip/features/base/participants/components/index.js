// @flow

export { default as ParticipantView } from './ParticipantView';
