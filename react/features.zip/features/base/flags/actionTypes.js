/**
 * The type of Redux action which updates the feature flags.
 *
 * {
 *     type: UPDATE_FLAGS,
 *     flags: Object
 * }
 *
 */
export const UPDATE_FLAGS = 'UPDATE_FLAGS';
