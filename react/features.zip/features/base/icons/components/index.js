// @flow

export { default as Icon } from './Icon';
