export { default as SoundCollection } from './SoundCollection';
