export const ONLINE_STATE_CHANGED_EVENT = 'network-info-online-status-change';
