/**
 * The name for Redux store key used by the 'base/net-info' feature.
 *
 * @type {string}
 */
export const STORE_NAME = 'features/base/net-info';
