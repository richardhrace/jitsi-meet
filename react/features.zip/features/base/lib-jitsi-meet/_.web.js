// @flow

declare var JitsiMeetJS: Object;

export default JitsiMeetJS;
