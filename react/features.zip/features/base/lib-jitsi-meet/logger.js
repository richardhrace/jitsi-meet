// @flow

import { getLogger } from '../logging/functions';

export default getLogger('features/base/lib-jitsi-meet');
