import './polyfills-browser';
import './WiFiStats';
