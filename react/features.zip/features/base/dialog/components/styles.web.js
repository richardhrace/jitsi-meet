/**
 * Placeholder styles for web to be able to use cross platform components
 * unmodified such as {@code DialogContent}.
 */
export default {};
