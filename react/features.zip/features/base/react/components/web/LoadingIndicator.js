/* @flow */

export { default } from '@atlaskit/spinner';
