// @flow

export { Switch as default } from 'react-native';
