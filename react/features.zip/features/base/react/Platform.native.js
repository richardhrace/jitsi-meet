/* @flow */

// Re-export react-native's Platform because we want to provide a minimal
// equivalent on Web.
import { Platform } from 'react-native';
export default Platform;
