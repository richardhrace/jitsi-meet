// @flow

export { default as StatelessAvatar } from './StatelessAvatar';
