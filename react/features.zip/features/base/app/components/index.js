export { default as BaseApp } from './BaseApp';
