// @flow

import Video from './native/Video';

export default Video;
