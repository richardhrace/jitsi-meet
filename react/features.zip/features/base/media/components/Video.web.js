// @flow

import Video from './web/Video';

export default Video;
