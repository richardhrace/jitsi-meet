// @flow

import Audio from './native/Audio';

export default Audio;
