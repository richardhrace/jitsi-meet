export { default as amplitude } from './Amplitude';
