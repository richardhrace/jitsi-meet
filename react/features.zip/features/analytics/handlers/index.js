export { default as AmplitudeHandler } from './AmplitudeHandler';
