// @flow

import { getLogger } from '../base/logging/functions';

export default getLogger('features/blur');
