// @flow

import { Component } from 'react';

/**
 * A React Component for adding a meeting URL to an existing calendar meeting.
 *
 * @extends Component
 */
class AddMeetingUrlButton extends Component<*> {
    /**
     * Implements React's {@link Component#render}.
     *
     * @inheritdoc
     */
    render() {
        // Not yet implemented.

        return null;
    }
}

export default AddMeetingUrlButton;
