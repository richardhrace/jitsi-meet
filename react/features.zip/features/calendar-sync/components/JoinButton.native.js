// @flow

import { Component } from 'react';

/**
 * A React Component for joining an existing calendar meeting.
 *
 * @extends Component
 */
class JoinButton extends Component<*> {
    /**
     * Implements React's {@link Component#render}.
     *
     * @inheritdoc
     */
    render() {
        // Not yet implemented.

        return null;
    }
}

export default JoinButton;
